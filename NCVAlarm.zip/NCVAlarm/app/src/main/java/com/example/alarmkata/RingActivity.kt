package com.example.alarmkata

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class RingActivity : Activity() {
    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var done = false
    private lateinit var status: TextView
    private lateinit var kw: String

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        kw = getSharedPreferences("p", 0).getString("kw", "bangun")!!.lowercase()
        status = TextView(this).apply {
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            text = "Ucapkan \"$kw\" untuk mematikan alarm"
        }
        setContentView(status)
        listen()
    }

    private fun listen() {
        if (done) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status.text = "Izin mikrofon belum diberikan. Buka aplikasi dan izinkan mikrofon."
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition tidak tersedia di HP ini."
            return
        }
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) { check(r); restart() }
                override fun onPartialResults(r: Bundle?) { check(r) }
                override fun onError(e: Int) { restart() }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            )
        }
    }

    private fun restart() {
        if (!done) h.postDelayed({ listen() }, 700)
    }

    private fun check(r: Bundle?) {
        val list = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
        if (list.any { it.lowercase().contains(kw) }) stopAlarm()
    }

    private fun stopAlarm() {
        done = true
        startService(Intent(this, AlarmService::class.java).setAction("STOP"))
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        sr?.destroy()
        super.onDestroy()
    }
}
